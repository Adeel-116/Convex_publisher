package com.example.lec06;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecycleStudentAdapter extends RecyclerView.Adapter<RecycleStudentAdapter.ViewHolder> {
    ArrayList<StudentModel> studentModels;
    Context context;

    public RecycleStudentAdapter(ArrayList<StudentModel> studentModels, Context context) {
        this.studentModels = studentModels;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.student_layout,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.img.setImageResource(studentModels.get(position).Img);
        holder.name.setText(studentModels.get(position).Name);
        holder.id.setText(studentModels.get(position).ID);
        holder.semester.setText(studentModels.get(position).Semester);
        holder.subject.setText(studentModels.get(position).Subject);
        holder.department.setText(studentModels.get(position).Department);
    }

    @Override
    public int getItemCount() {
        return studentModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView img;
        TextView name,id,subject,semester,department;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            img = itemView.findViewById(R.id.img);
            name = itemView.findViewById(R.id.name);
            semester = itemView.findViewById(R.id.std_sem);
            subject = itemView.findViewById(R.id.std_subj);
            department = itemView.findViewById(R.id.std_dpt);
            id = itemView.findViewById(R.id.std_id);
        }
    }
}
