package com.example.lec06;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<StudentModel> std_data = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        init();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        std_data.add(new StudentModel(R.drawable.image1,"Ali","100","5","MD","CS"));
        std_data.add(new StudentModel(R.drawable.image2,"Ahmed","101","5","MD","DS"));
        std_data.add(new StudentModel(R.drawable.image3,"Muhammad","102","5","MD","SE"));
        std_data.add(new StudentModel(R.drawable.image4,"Hussain","103","5","MD","IT"));

        RecycleStudentAdapter adapter = new RecycleStudentAdapter(std_data,this);
        recyclerView.setAdapter(adapter);
    }
    public void init()
    {
        recyclerView = findViewById(R.id.student_data);
    }
}