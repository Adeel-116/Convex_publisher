package com.example.lec06;

public class StudentModel {
    int Img;
    String Name,ID,Semester,Subject,Department;

    public StudentModel(int img, String name, String ID, String semester, String subject, String department) {
        Img = img;
        Name = name;
        this.ID = ID;
        Semester = semester;
        Subject = subject;
        Department = department;
    }
}
